var myaddress = "your ETH public address"
var myprivatekey = "your ETH private key to that address"
var myseed = "your wallet seed" //only give this if your privatekey is stored in a wallet with no privatekey accessibility example (hardwarewallets)
var networks = "1" //1 = ETH , 2 = BNB , 3 = polygon
var maxspend = "0.5" // max eth you want to spend. Note: Make sure you have that amount in the wallet you provided.
var tokenaddress = "" // Optional if your trying to front run one specific token ,enter token's contract address